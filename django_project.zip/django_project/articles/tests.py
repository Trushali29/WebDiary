from django.test import TestCase
# test with databases
from django.contrib.auth import get_user_model # access user information
# able to load a clinet browser by provindg it a url pattern name to reverse
from django.urls import reverse 
from .models import Article

class TestSite(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username = 'sampleuser',
            email = 'sample@aol.com',
            password = 'password'
        )

        self.article = Article.objects.create(
            title = 'Rabbits',
            text = '''Rabbits, also known as bunnies or bunny rabbits, are small mammals in the family Leporidae (which also includes the hares), which is in the order Lagomorpha (which also includes the pikas). Oryctolagus cuniculus is the European rabbit, including its descendants, the world's 305 breeds[1] of domestic rabbit. Sylvilagus includes 13 wild rabbit species, among them the seven types of cottontail. The European rabbit, which has been introduced on every continent except Antarctica, is familiar throughout the world as a wild prey animal, a domesticated form of livestock and a pet. With its widespread effect on ecologies and cultures, in many areas of the world, the rabbit is a part of daily life – as food, clothing, a companion, and a source of artistic inspiration.''',
            author = self.user, )
        
    def test_article_title(self):
        article = Article(title = 'Rabbits')
        self.assertEqual(str(article), article.title)


    # verfiy is the content in th database is same as given
    def test_setting_all(self):
        self.assertEqual(f'{self.article.title}', "Rabbits")
        self.assertEqual(f'{self.article.author}', 'sampleuser')
        self.assertEqual(f'{self.article.text}','''Rabbits, also known as bunnies or bunny rabbits, are small mammals in the family Leporidae (which also includes the hares), which is in the order Lagomorpha (which also includes the pikas). Oryctolagus cuniculus is the European rabbit, including its descendants, the world's 305 breeds[1] of domestic rabbit. Sylvilagus includes 13 wild rabbit species, among them the seven types of cottontail. The European rabbit, which has been introduced on every continent except Antarctica, is familiar throughout the world as a wild prey animal, a domesticated form of livestock and a pet. With its widespread effect on ecologies and cultures, in many areas of the world, the rabbit is a part of daily life – as food, clothing, a companion, and a source of artistic inspiration.''' )
    
    # to get 200 response code
    def test_response(self):
        response = self.client.get(reverse('home'))
        # verify if the response code is 200
        self.assertEqual(response.status_code, 200)
        # verify if the title is same
        self.assertContains(response,'Rabbits')
        # verify use of correct template
        self.assertTemplateUsed(response, 'home.html')

    def test_article_detail_view(self):
        response = self.client.get('/article/1/')
        bad_response = self.client.get('/article/200/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(bad_response.status_code, 404)
        self.assertContains(response, 'Rabbits')
        self.assertTemplateUsed(response, 'article_detail.html')

    # creation, update and delete is not done section 9

    