from django.db import models
from django.urls import reverse
# author having different post if author deleted its record in entire database is deleted.

class Article(models.Model):
    title = models.CharField(max_length=200)
    text = models.TextField()
    # create a author and if it's delete then delete all the related blogs of the author from all the databases
    author = models.ForeignKey(
        'auth.User',
        on_delete = models.CASCADE,
        default = 1, 
    )
    photo = models.ImageField(upload_to="gallery", default = 'cat.jpg')

    def __str__(self):
        return self.title
    # to redirect user to home page to all articles
    def get_absolute_url(self):
        return reverse('article_detail', args=[str(self.id)])

