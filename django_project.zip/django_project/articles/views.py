from django.views.generic import ListView, DetailView, UpdateView, DeleteView
from django.views.generic.edit import CreateView
from .models import Article
from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse_lazy

# list of all html views

class HomePageView(ListView):
    model = Article
    template_name = 'home.html'
    context_object_name = 'all_articles_list'

class ArticleDetailView(DetailView):
    model = Article
    template_name = 'article_detail.html'


class ArticleCreateView(CreateView):
    model = Article
    template_name = 'add_article.html'
    fields = ['title', 'author','text','photo']
    
class ArticleUpdateView(UpdateView):
    model = Article
    template_name = 'edit_article.html'
    fields = ['title','text', 'photo']

class ArticleDeleteView(DeleteView):
    model = Article
    template_name = 'delete_article.html'
    success_url = reverse_lazy('home')
